This file describes how to use each program. In each folder, there should be 2 Dev projects: one is the main program (ldiv.dev); one serves as scripts. (If you do not have Dev c++, please simply examine the project file (.dev), you can easily find the list of corresponding files and they can be complied in most of other c++ compilers. )

For simpler implementation and simpler debugging, global arrays with fixed sizes are used in the programs. The size of arrays are hard-coded in the programs, which can be found at the beginning part of the codes. Please change them accordingly for different set of parameters. *IMPORTANT* sometimes the program will die because the parameters are set too large. Please fix the values manually.

A script (a c++ program itself) is provided too. You can use it to execute the programs with the parameters used in the paper. There are 2 sets of commands in each script (one for Census, one for Adult). Please change the codes inside it for different dataset. The output will goes to the `log' folder. Here is the log name format:

`A-x-y.txt' -> Program A on CENSUS 100k dataset, d = x, l = y. E.g., AT-2-5.txt -> AT on Census 100k dataset, d = 2, l = 5.

l : parameter to l-diversity
d : dimensionality of QID

**************************************************
******************** Program ********************
**************************************************

The main Dev project of each program: ldiv.dev

NH (non-homogeneous + set representation + new partitioning)
=============================================================

Usage:

ldiv [input data file name] [file name of description to data file] [k] [# dimensions as QID]

++++++++++++
+Parameters+
++++++++++++

1. Input data format

[tuple_id] [value 1] [value 2] ... [value d]

2. Format of description to data file

[number of dimensions, d]
[lowest value to dimension 1] [lowest value to dimension 2] ...  [lowest value to dimension d] 
[highest value to dimension 1] [highest value to dimension 2] ... [highest value to dimension d]

3. k

parameter of k-anonymity

4. To indicate whether homogeneous or non-homogeneous generalization is used (only HS)

0 = homogeneous
1 = non-homogeneous (not fully implemented, randomization is not done)

5. Number of dimensions are QID

Suppose the input is x
The first x dimensions are treated as QID while others are retained in the generalization