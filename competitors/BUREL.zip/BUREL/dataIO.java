import java.io.* ;
import java.util.ArrayList;

public class dataIO {
      
    public Record Recs[] ; //the input tuples
        
    private BufferedWriter out ;
    private BufferedWriter non_out ;    
        
    public statistics Stats ; //the class for statistics
    public ArrayList<Group> Glist ;//to records all formed ECs    
    
    public dataIO (){ 
    }
    
    public void init( String rec_file, String anon_file,
            String stat_file ) {        
        try{           
            //the class for statistics
            Stats = new statistics( stat_file ) ;
            Stats.setStartTime() ;
            
            //read in records
            Recs = new Record[global.NUM] ;
            read_records(rec_file);
            
            //files to store anonymized tuples with their original ones
            out = new BufferedWriter(new FileWriter(anon_file));
            String str = "non_" ;
            str += anon_file ;
            non_out = new BufferedWriter(new FileWriter(str));                        
            
            Glist = new ArrayList<Group> () ;
        }catch (IOException e){
            System.out.println("IOException:");
            e.printStackTrace();
        }                
    }//end of function 'init'                      
    
    public void finish () {
        makeStats() ;

        try{
            out.close();
            non_out.close();            
        }catch (IOException e){
            System.out.println("IOException:");
            e.printStackTrace();
        }                        
    }             
    
    private void makeStats(){
        Stats.setEndTime(); //it is the time that all tuples are anonymized
        
        //the statistics for each EC
        int gNum = Glist.size() ;
        for( int i = 0 ; i < gNum ; i++ ){
            Group G = Glist.get(i) ;
            G.get_MBR() ;
            output_recs(G) ;
            Stats.output_group(G);
        }
        
        //for the closeness of generated ECs
        tcloseness T = new tcloseness(Recs) ;
        int SAindex = global.DMSION - 1 ;     
        if( global.isNumeric[SAindex] == true ){
            //number of sensitive values
            int SN = global.domain_finish[SAindex] + 1 ;            
            int senValues[] = new int[SN] ;
            for( int j = 0 ; j < SN ; j++ )
                senValues[j] = j ;
            
            T.init_numDist(senValues) ;
        }
        else //
            T.init_catDist( global.occup );
        T.maxDist(Glist) ;
        
        //do the summarized statistics
        Stats.summary( T.max, T.min, T.avg, Glist) ;
        
        Stats.finish(); //close the statistics file
    }
    
    private void read_records ( String file )throws IOException  {
        BufferedReader in = new BufferedReader(new FileReader(file));
        String inLine ;
        
        int i = 0 ;
        while( (inLine = in.readLine()) != null ){
            Recs[i] = new Record( inLine ) ;
            i ++ ;            
        }
        
        in.close(); //close the tuple file
    }//end of function 'read_records'         
    
    public void addGroup ( Group G ){
         Glist.add(G);
    }

    public void addGs ( ArrayList<Group> Gs){        
        Glist.addAll(Gs);
    }

    private void output_recs ( Group G ){
        //obtain the string of the MBR
        if ( G.ascii_MBR.length() == 0 )
            G.toString() ;
        
        int gSize = G.size() ;
        //for debugging
        /*if(gSize <=1){
            String betaECSize = "" ;
            betaECSize += global.BETA ;
            betaECSize += "; a group has size<=1" ; 
            System.out.println( betaECSize ) ;
        }*/
                
        try{
            for ( int i = 0 ; i < gSize ; i ++ ){
                String str = new String ( G.ascii_MBR ) ;
                Record rec = G.members.get(i) ;                
                str += rec.data[global.DMSION-1] ;//sensitive value
                out.write(str);
                out.newLine() ;
                
                String myStr = rec.toStr() ;
                non_out.write(myStr);
                non_out.newLine() ;
            }
        }catch (IOException e){
            System.out.println("IOException:");
            e.printStackTrace();
        }               
    }//end of function 'output_recs'       
}
