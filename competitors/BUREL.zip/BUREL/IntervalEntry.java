public class IntervalEntry {
    int start;
    int finish;
    int count;
    
    public IntervalEntry () {} 
}
